# PixelFix Computer Solutions

**Student Name:** ONAKO SILO

**Student Number:** ST10520222

**Subject:** Web Development

**Subject Code:** WEDE5112

**Academic Year:** 2026


## Project Overview

Pixelite Computer Solutions is a fictional small business that provides affordable and reliable computer repair and technical support services in Cape Town, South Africa.

The purpose of this project is to design and develop a professional, user-friendly and responsive website for Pixelite Computer Solutions. The website provides customers with information about the organisation, its services, locations and contact details.

The website is designed to serve students, home computer users, gamers, remote workers, freelancers and small businesses requiring computer-related assistance.


## Website Goals and Objectives

The main goal of the website is to establish a professional online presence for Pixelite Computer Solutions and make it easier for customers to access information and communicate with the organisation.

The objectives are to:

- Provide clear information about Pixelite and its services.
- Allow customers to make service enquiries online.
- Provide contact information and multiple business locations.
- Improve the organisation's online visibility.
- Create an easy-to-navigate and responsive website.
- Build customer trust through professional design and clear information.
- Provide a convenient way for customers to request technical assistance.


## Key Features and Functionality

The website includes the following features:

- Responsive navigation menu.
- Homepage with hero image and call-to-action.
- Organisation history, mission and vision.
- Team member information.
- Detailed service descriptions.
- Online service enquiry form.
- Contact form.
- Multiple business locations.
- Embedded maps.
- Responsive layout for different screen sizes.
- JavaScript form functionality.
- Consistent branding and visual design.
- Footer navigation and contact information.


## Website Pages

| Page | File | Purpose |
|---|---|---|
| Homepage | index.html | Introduction, hero section and call-to-action |
| About Us | about.html | Organisation history, mission, vision and team |
| Services | services.html | Detailed information about services |
| Enquiry | enquiry.html | Customer service enquiry form |
| Contact | contact.html | Contact details, locations, maps and contact form |


## Timeline and Milestones

| Week | Milestone |
|---|---|
| Week 1 | Organisation research and project planning |
| Week 2 | Proposal development and wireframes |
| Week 3 | HTML page development |
| Week 4 | CSS styling and layout |
| Week 5 | JavaScript functionality |
| Week 6 | Website testing and debugging |
| Week 7 | User experience improvements |
| Week 8 | Final documentation and submission |


## Sitemap

```text
Pixelite Computer Solutions
│
├── Home
│   └── index.html
│
├── About Us
│   └── about.html
│
├── Services
│   └── services.html
│
├── Enquiry
│   └── enquiry.html
│
└── Contact
    └── contact.html